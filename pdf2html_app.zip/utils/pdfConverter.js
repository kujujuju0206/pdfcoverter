const fs = require('fs-extra');
const path = require('path');
const { PDFDocument } = require('pdf-lib');
const { JSDOM } = require('jsdom');
const { spawn } = require('child_process');
const archiver = require('archiver');

/**
 * PDFをHTMLとCSSに変換する関数
 * @param {string} pdfPath - PDFファイルのパス
 * @param {string} fileName - 出力ファイル名のベース
 * @param {string} outputDir - 出力ディレクトリ
 * @returns {Promise<Object>} - 変換結果
 */
async function pdfToHtml(pdfPath, fileName, outputDir) {
  try {
    // 出力ディレクトリの作成
    const projectDir = path.join(outputDir, fileName);
    fs.ensureDirSync(projectDir);
    
    // PDFの解析
    const pdfBytes = await fs.readFile(pdfPath);
    const pdfDoc = await PDFDocument.load(pdfBytes);
    const numPages = pdfDoc.getPageCount();
    
    // PDFのメタデータ取得
    const { width, height } = pdfDoc.getPage(0).getSize();
    
    // PDFを画像に変換（Python scriptを使用）
    await convertPdfToImages(pdfPath, projectDir);
    
    // HTMLとCSSの生成
    const { html, css } = generateHtmlCss(projectDir, numPages, width, height);
    
    // ファイルの保存
    await fs.writeFile(path.join(projectDir, 'index.html'), html);
    await fs.writeFile(path.join(projectDir, 'styles.css'), css);
    
    // ZIPファイルの作成
    await createZipArchive(projectDir, path.join(outputDir, `${fileName}.zip`));
    
    return {
      success: true,
      outputDir: projectDir,
      files: {
        html: path.join(projectDir, 'index.html'),
        css: path.join(projectDir, 'styles.css'),
        zip: path.join(outputDir, `${fileName}.zip`)
      }
    };
  } catch (error) {
    console.error('PDF変換エラー:', error);
    throw new Error(`PDF変換に失敗しました: ${error.message}`);
  }
}

/**
 * PDFを画像に変換する関数
 * @param {string} pdfPath - PDFファイルのパス
 * @param {string} outputDir - 出力ディレクトリ
 * @returns {Promise<void>}
 */
function convertPdfToImages(pdfPath, outputDir) {
  return new Promise((resolve, reject) => {
    const imagesDir = path.join(outputDir, 'images');
    fs.ensureDirSync(imagesDir);
    
    const pythonScript = `
import sys
from pdf2image import convert_from_path
import os

# PDFをイメージに変換
images = convert_from_path('${pdfPath}', dpi=300)
print(f'PDFページ数: {len(images)}')

# 各ページを保存
for i, image in enumerate(images):
    image_path = os.path.join('${imagesDir}', f'page_{i+1}.png')
    image.save(image_path, 'PNG')
    print(f'ページ {i+1} を保存しました: {image_path}')
`;
    
    const scriptPath = path.join(outputDir, 'convert_pdf.py');
    fs.writeFileSync(scriptPath, pythonScript);
    
    const pythonProcess = spawn('python3', [scriptPath]);
    
    pythonProcess.stdout.on('data', (data) => {
      console.log(`Python出力: ${data}`);
    });
    
    pythonProcess.stderr.on('data', (data) => {
      console.error(`Python エラー: ${data}`);
    });
    
    pythonProcess.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Python スクリプトが終了コード ${code} で終了しました`));
      }
    });
  });
}

/**
 * HTMLとCSSを生成する関数
 * @param {string} projectDir - プロジェクトディレクトリ
 * @param {number} numPages - PDFのページ数
 * @param {number} width - PDFの幅
 * @param {number} height - PDFの高さ
 * @returns {Object} - HTMLとCSSの内容
 */
function generateHtmlCss(projectDir, numPages, width, height) {
  // HTMLの生成
  const dom = new JSDOM('<!DOCTYPE html><html><head></head><body></body></html>');
  const document = dom.window.document;
  
  // メタタグの追加
  const meta = document.createElement('meta');
  meta.setAttribute('charset', 'UTF-8');
  document.head.appendChild(meta);
  
  const viewport = document.createElement('meta');
  viewport.setAttribute('name', 'viewport');
  viewport.setAttribute('content', 'width=device-width, initial-scale=1.0');
  document.head.appendChild(viewport);
  
  // タイトルの追加
  const title = document.createElement('title');
  title.textContent = 'PDF to HTML Conversion';
  document.head.appendChild(title);
  
  // CSSリンクの追加
  const cssLink = document.createElement('link');
  cssLink.setAttribute('rel', 'stylesheet');
  cssLink.setAttribute('href', 'styles.css');
  document.head.appendChild(cssLink);
  
  // コンテナの作成
  const container = document.createElement('div');
  container.className = 'pdf-container';
  document.body.appendChild(container);
  
  // ページごとのコンテンツ追加
  for (let i = 0; i < numPages; i++) {
    const pageDiv = document.createElement('div');
    pageDiv.className = 'pdf-page';
    pageDiv.id = `page-${i + 1}`;
    
    // 画像の背景として設定
    pageDiv.style.backgroundImage = `url('images/page_${i + 1}.png')`;
    pageDiv.style.width = `${width}px`;
    pageDiv.style.height = `${height}px`;
    
    container.appendChild(pageDiv);
    
    // 画像プレースホルダーの追加（例：ファーストビューの男性画像）
    if (i === 0) {
      // ヘッダー部分
      addImagePlaceholder(document, pageDiv, {
        top: '10px',
        right: '10px',
        width: '150px',
        height: '50px',
        label: 'ロゴ画像'
      });
      
      // ファーストビューの男性画像
      addImagePlaceholder(document, pageDiv, {
        top: '150px',
        right: '50px',
        width: '450px',
        height: '550px',
        label: 'ノートPCを持ち、ヘッドフォンをしている男性'
      });
      
      // その他のプレースホルダー（コンテンツに応じて追加）
      addImagePlaceholder(document, pageDiv, {
        top: '800px',
        left: '50%',
        width: '350px',
        height: '200px',
        label: '悩んでいる人物（男女）のイラスト'
      });
    }
  }
  
  // CSSの生成
  const css = `
body {
  margin: 0;
  padding: 0;
  font-family: 'Helvetica Neue', Arial, sans-serif;
}

.pdf-container {
  position: relative;
  margin: 0 auto;
  max-width: 100%;
}

.pdf-page {
  position: relative;
  margin: 0 auto;
  background-repeat: no-repeat;
  background-size: contain;
  background-position: center top;
}

.image-placeholder {
  position: absolute;
  background-color: #f0f0f0;
  border: 2px dashed #ccc;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  padding: 10px;
  box-sizing: border-box;
  color: #666;
  font-size: 14px;
}

.image-placeholder::before {
  content: '画像の配置エリア';
  font-weight: bold;
  margin-bottom: 5px;
}

@media (max-width: 768px) {
  .pdf-page {
    transform: scale(0.8);
    transform-origin: top center;
  }
}
`;
  
  return {
    html: dom.serialize(),
    css: css
  };
}

/**
 * 画像プレースホルダーを追加する関数
 * @param {Document} document - DOMドキュメント
 * @param {HTMLElement} parent - 親要素
 * @param {Object} options - プレースホルダーのオプション
 */
function addImagePlaceholder(document, parent, options) {
  const placeholder = document.createElement('div');
  placeholder.className = 'image-placeholder';
  
  // スタイルの設定
  Object.entries(options).forEach(([key, value]) => {
    if (key !== 'label') {
      placeholder.style[key] = value;
    }
  });
  
  // ラベルの追加
  if (options.label) {
    const label = document.createElement('span');
    label.textContent = options.label;
    placeholder.appendChild(label);
  }
  
  // サイズ情報の追加
  if (options.width && options.height) {
    const size = document.createElement('span');
    size.textContent = `サイズ: ${options.width}x${options.height}`;
    placeholder.appendChild(size);
  }
  
  parent.appendChild(placeholder);
}

/**
 * ZIPアーカイブを作成する関数
 * @param {string} sourceDir - ソースディレクトリ
 * @param {string} outputPath - 出力ZIPファイルのパス
 * @returns {Promise<void>}
 */
function createZipArchive(sourceDir, outputPath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', {
      zlib: { level: 9 } // 圧縮レベル
    });
    
    output.on('close', () => {
      console.log(`ZIPアーカイブが作成されました: ${outputPath}`);
      resolve();
    });
    
    archive.on('error', (err) => {
      reject(err);
    });
    
    archive.pipe(output);
    archive.directory(sourceDir, false);
    archive.finalize();
  });
}

module.exports = {
  pdfToHtml
};
