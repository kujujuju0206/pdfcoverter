const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { pdfToHtml } = require('./utils/pdfConverter');

const app = express();
const PORT = process.env.PORT || 3000;

// テンプレートエンジンの設定
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 静的ファイルの提供
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/output', express.static(path.join(__dirname, 'output')));

// アップロードディレクトリの設定
const uploadDir = path.join(__dirname, 'uploads');
const outputDir = path.join(__dirname, 'output');
fs.ensureDirSync(uploadDir);
fs.ensureDirSync(outputDir);

// ファイルアップロードの設定
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  fileFilter: function (req, file, cb) {
    if (file.mimetype !== 'application/pdf') {
      return cb(new Error('PDFファイルのみアップロード可能です'), false);
    }
    cb(null, true);
  },
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB制限
  }
});

// ルート
app.get('/', (req, res) => {
  res.render('index', { title: 'PDFからHTMLへの変換ツール' });
});

// PDFアップロードと変換処理
app.post('/upload', upload.single('pdfFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'ファイルがアップロードされていません' });
    }

    const pdfPath = req.file.path;
    const fileName = path.basename(pdfPath, path.extname(pdfPath));
    
    // PDF変換処理
    const result = await pdfToHtml(pdfPath, fileName, outputDir);
    
    res.json({
      success: true,
      message: '変換が完了しました',
      data: {
        htmlPath: `/output/${fileName}/index.html`,
        cssPath: `/output/${fileName}/styles.css`,
        zipPath: `/output/${fileName}.zip`,
        fileName: req.file.originalname
      }
    });
  } catch (error) {
    console.error('変換エラー:', error);
    res.status(500).json({ error: '変換処理中にエラーが発生しました: ' + error.message });
  }
});

// サーバー起動
app.listen(PORT, '0.0.0.0', () => {
  console.log(`サーバーが起動しました: http://localhost:${PORT}`);
});
